1. Make sure you have node.js installed on your computer.

2. Open index.js with with Notepad ++.

3. Replace "TOKEN HERE" with your bot's token.

4. Replace the variables in config const with the ones you want.

5. Open start.bat and your bot should be online.

6. I'm not responsable for what you do with this bot.

